function dispHello()
{
	document.write("<b>Hello World</b>");
}
document.write("This text is displayed from the script tag embedded in the Head tag of the document");
