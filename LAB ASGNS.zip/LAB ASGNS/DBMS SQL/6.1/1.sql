insert into customerMaster values(&customerId,'&customername','&address1','&address2','&gender',&age,&phoneno);
