select Staff_Name as "Name",Design_code as "Designation Code" 
	from Staff_Master 
	where HireDate < '01-jan-2003' and Staff_sal between 12000 and 25000;
