select * from Staff_Master where Mgr_code is null;
