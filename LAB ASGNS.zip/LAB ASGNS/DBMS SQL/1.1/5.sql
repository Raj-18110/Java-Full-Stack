CREATE TABLE Emp
        ( Empno number(4) not null,
	  Ename varchar2(10),
	  job varchar2(9),
	  mgr number(4),
	  Hiredate date,
	  Sal number(7,2),
	  Comm number(7,2),
	  Deptno number(2)
	 );

insert into Emp values(1,'nitika','full time','1','01-oct-2002',15000,1,1);
insert into Emp values(2,'aman','full time',null,'11-aug-2003',25000,2,2);
insert into Emp values(3,'harleen','part time','1','21-oct-2001',35000,1,1);
insert into Emp values(4,'rahul','part time',null,'08-april-2018',45000,3,2);
insert into Emp values(5,'vinay','full time','1','10-nov-2015',65000,3,1);
insert into Emp values(6,'nitin','full time','2','27-nov-2000',18000,2,2);
------------------------------------

CREATE TABLE Designation_Master
	( Design_code number(3) not null,
	  Design_name varchar2(50)
	);

insert into Designation_Master values(101, 'senior analyst');
insert into Designation_Master values(102, 'analyst');
insert into Designation_Master values(101, 'senior analyst');
insert into Designation_Master values(102, 'analyst');
insert into Designation_Master values(101, 'senior analyst');
insert into Designation_Master values(102, 'analyst');
------------------------------------

CREATE TABLE Department_Master
	( Dept_Code number(2) not null,
	  Dept_name varchar2(50)
	);

	insert into Department_Master values(1,'cse');
	insert into Department_Master values(2,'ece');
	insert into Department_Master values(3,'ee');
	insert into Department_Master values(4,'civil');

---------------------------------------

CREATE TABLE Student_Master
	( Student_Code number(6) not null,
	  Student_name varchar2(50) not null,
	  Dept_Code number(2),
	  Student_dob date,
	  Student_Address varchar2(240)
	);
	

insert into Student_Master values(111,'nitika',10,'01-jan-1994','abc');
insert into Student_Master values(112,'aman',10,'11-jan-1994','xyz');
insert into Student_Master values(113,'sahil',12,'31-dec-1993','abc');
insert into Student_Master values(114,'deepu',12,'07-jan-1994','mno');
insert into Student_Master values(115,'priyanka',10,'01-oct-1994','xyz');
insert into Student_Master values(116,'navi',10,'01-feb-1994','abc');
insert into Student_Master values(117,'priyanka',10,'01-oct-1994','xyz');
insert into Student_Master values(118,'naveen',20,'01-feb-1994','abc');
insert into Student_Master values(115,'priyankan',30,'01-oct-1994','xyz');
insert into Student_Master values(119,'nav',10,'01-feb-1994','abc');


-------------------------------------------

CREATE TABLE Student_Marks
	( Student_Code number(6),
	  Student_Year number not null,
	  Subject1 number(3),
	  Subject2 number(3),
	  Subject3 number(3)
	);

--------------------------------------------

CREATE TABLE Staff_Master
	 ( Staff_code number(8) not null,
	   Staff_Name varchar2(50) not null,
	   Design_code number,
	   Dept_code number,
	   HireDate date,
	   Staff_dob date,
	   Staff_address varchar2(240),
	   Mgr_code number(8),
	   Staff_sal number(10,2)
	  );

alter table staff_master 
add mgr_name varchar(50);	 
	 
insert into Staff_Master values ( 110,'rahul',101,1,'01-oct-2002','10-oct-1994','model colony','1000',15000);
insert into Staff_Master values ( 111,'nitika',101,2,'01-aug-2000','12-april-1993','abc colony','1001',23000);
insert into Staff_Master values ( 112,'aman',102,1,'01-nov-2008','26-may-1992','model colony','1002',55000);
insert into Staff_Master values ( 113,'vivek',101,2,'01-feb-2001','15-dec-2000','xyz colony','1003',21000);
insert into Staff_Master values ( 114,'priya',102,1,'01-dec-2003','09-feb-1994','xyz colony','1004',15000);
insert into Staff_Master values ( 115,'mittali',102,2,'01-march-2010','24-jan-1995','abc colony','1005',35000);
insert into Staff_Master values ( 116,'ri_a',101,2,'01-feb-2001','15-dec-2000','xyz colony',null,21000);
insert into Staff_Master values ( 117,'pra_chi',102,1,'01-dec-2003','09-feb-1994','xyz colony',null,15000);
insert into Staff_Master values ( 118,'raman',102,2,'01-march-2010','24-jan-1995','abc colony','1008',35000);
insert into Staff_Master values ( 119,'ramesh',102,3,'01-march-2010','24-jan-1995','abc colony','1009',35000);
insert into Staff_Master values ( 120,'richa',101,2,'01-feb-2001','15-dec-2000','xyz colony',null,11000);

update staff_master set mgr_name='aaa' where staff_code=110;
update staff_master set mgr_name='bbb' where staff_code=111;
update staff_master set mgr_name='ccc' where staff_code=112;
update staff_master set mgr_name='aaa' where staff_code=113;
update staff_master set mgr_name='aaa' where staff_code=114;
update staff_master set mgr_name='bbb' where staff_code=115;
update staff_master set mgr_name='ccc' where staff_code=116;
update staff_master set mgr_name='ccc' where staff_code=117;
update staff_master set mgr_name='ccc' where staff_code=118;
update staff_master set mgr_name='bbb' where staff_code=119;

------------------------------------------------

CREATE TABLE Book_Master
	( Book_Code number(10) not null,
 	  Book_Name varchar2(50) not null
	  Book_pub_year number,
	  Book_pub_author varchar2(50) not null
	 );

insert into Book_Master values(110,'rd sharma',2002,'abc');
insert into Book_Master values(111,'let us'||'&'||'c',2001,'abc');
insert into Book_Master values(112,'maths',2008,'xyz');
insert into Book_Master values(113,'phy'||'&'||'ics',2004,'xyz');
insert into Book_Master values(114,'chemistry',2007,'aaa');
insert into Book_Master values(115,'eme',2010,'bbb');
--------------------------------------------

CREATE TABLE Book_Transactions
	( Book_Code number,
	  Student_code number,
	  Staff_code number,
	  Book_Issue_date date not null,
	  Book_expected_return_date date not null,
	  Book_actual_return_date date
	);
	
	insert into book_transactions values(110,111,110,'01-oct-2018','19-sep-2018','20-sep-2018');
---------------------------------------------------------------------------------------------------------------
1
---------------------------------------------------------------------------------------------------------------
1.1 Data Query Language
----------------------------------------------------------------------------------------------------------------
1.
select Staff_Name as "Name",Design_code as "Designation Code" from Staff_Master where HireDate < '01-jan-2003' and Staff_sal between 12000 and 25000;

-----------------------------------------------------------------------------------------------------------------
2.
select Staff_code, Staff_Name,Dept_code from Staff_Master where (months_between(sysdate,hiredate))>=216 order by hiredate desc;
------------------------------------------------------------------------------------------------------------------

3.
select * from Staff_Master where Mgr_code is null;

--------------------------------------------------------------------------------------------------------------------

4.
SELECT * FROM Book_Master where Book_pub_year between 2001 and 2004 and Book_Name like '%&%';
-------------------------------------------------------------------------------------------------------------------

5.
select Staff_Name from Staff_Master where Staff_Name like '%\_%' ESCAPE '\';

-----------------------------------------------------------------------------------------------------------------
2.1 Single row functions
--------------------------------------------------------------------------------------------------------------------
1.
select Staff_Name, lpad(Staff_sal,15,'$') as Salary from Staff_Master;

-----------------------------------------------------------------------------------------------------------------

2.
select student_name, to_char(student_dob,'MONTH DD YYYY') AS DATE_BIRTH from student_master WHERE to_char(student_dob,'DAY') like '%SATURDAY%' or to_char(student_dob,'DAY') like '%SUNDAY%';

-------------------------------------------------------------------------------------------------

3. 
select staff_name, ROUND(MONTHS_BETWEEN(SYSDATE,HIREDATE)) AS "MONTHS WORKED" FROM STAFF_MASTER order by "MONTHS WORKED" DESC;

------------------------------------------------------------------------------------------------------------------------------

4.
select * from staff_master where to_char(hiredate,'DD') between 1 and 15 and to_char(hiredate,'MONTH') like '%DECEMBER%';

-------------------------------------------------------------------------------------------------------------------------------------

5.
select Staff_Name, Staff_sal, 
       case  
       when Staff_sal>=50000 then 'A'
	   when Staff_sal>=25000 AND STAFF_SAL <50000 then 'B'
	   when Staff_sal>=10000 AND STAFF_SAL <25000 then 'C'
	   else 'D'
	   end case 
	   from staff_master;
	   

-----------------------------------------------------------------------------------------------------------------------------------

6.
select staff_name,hiredate, to_char(hiredate,'DAY') as DAY from staff_master order by to_char(hiredate,'DAY') ;

---------------------------------------------------------------------------------------------------------------

7.
select instr('Mississippi', 'i',2,3) from dual;

----------------------------------------------------------------------------------------------------------

8. 
select to_char(next_day(last_day(sysdate)-7,'FRIDAY')) from dual;

----------------------------------------------------------------------------------------------------------

9.
select student_code,student_name,dept_code,
	DECODE ( dept_code, 20, 'Electricals', 30, 'Electronics', 'Others') as "Dept Name"
		from student_master;
---------------------------------------------------------------------------------------------------------

2.2
---------------------------------------------------------------------------------------------------------

1.		
select round(max(staff_sal)) as "Maximum", round(min(staff_sal)) as "Minimum", round(sum(staff_sal)) as "Total", round(avg(staff_sal)) as "Average" from staff_master group by dept_code;		

----------------------------------------------------------------------------------------------------------

2.
select dept_code, count(mgr_code) as "Total Number of Managers" from staff_master group by dept_code;

-----------------------------------------------------------------------------------------------------------

3.
select dept_code,sum(staff_sal) from staff_master where mgr_code is null group by dept_code having sum(staff_sal)>20000;
----------------------------------------------------------------------------------------------------------

3.1 Joins and subqueries
-----------------------------------------------------------------------------------------------------------

1.
select a.staff_name,a.dept_code,b.dept_name,a.staff_Sal 
	from staff_master a 
	join department_master b on a.dept_code=b.dept_code 
	where a.staff_sal>20000;

-----------------------------------------------------------------------------------------------------------

2.
select a.staff_code as "Staff#",a.staff_name as Staff,b.dept_name,a.mgr_code as Mgr#,a.mgr_name as Manager
 from staff_master a 
 join department_master b on a.dept_code=b.dept_code;

--------------------------------------------------------------------------------------------------------------

3.
select a.student_code,a.student_name,b.book_code,b.book_name 
      from student_master a 
	  join book_transaction c on a.student_code=c.student_code 
	  join book_master b on c.book_code=b.book_code 
	  where TO_CHAR(c.BOOK_EXPECTED_RETURN_DATE,'DD MM YYYY')  LIKE TO_CHAR(SYSDATE,'DD MM YYYY'); 
-----------------------------------------------------------------------------------------------------------------

4.
select a.staff_code,a.staff_name, b.dept_name, c.design_name, d.book_code,d.book_name, e.book_issue_date
    from staff_master a
	    join department_master b on a.dept_code=b.dept_code
	    join designation_master c on a.design_code=c.design_code
	    join book_transactions e on a.staff_code=e.staff_code
	    join book_master d on e.book_code=d.book_code
	     where months_between(to_char(e.book_issue_date,'mm'), to_char(sysdate,'mm'))<1;
-----------------------------------------------------------------------------------

5.
select a.staff_code,a.staff_name,c.design_name, b.dept_name, d.book_code,d.book_name,d.book_pub_author
	from staff_master a
	    join department_master b on a.dept_code=b.dept_code
	    join designation_master c on a.design_code=c.design_code
	    join book_transactions e on a.staff_code=e.staff_code
	    join book_master d on e.book_code=d.book_code
----------------------------------------------------------------------------------------
6.
select staff_code,staff_name,staff_sal 
	from staff_master where staff_sal<(select avg(staff_sal) from staff_master);
-------------------------------------------------------------------------------------------
7.
select book_pub_author as "author name",book_name from book_master ;
------------------------------------------------------------

8.
select b.staff_code,a.staff_name,c.dept_name 
	from staff_master a
		join book_transactions b on a.staff_code=b.staff_code
		join department_master c on c.dept_code=a.dept_code
		GROUP BY a.STAFF_NAME HAVING COUNT(b.STAFF_count)>1;
--------------------------------------------------------------------------

9.
select a.student_code,a.student_name,b.dept_name 
	from student_master a
	join department_master b on a.dept_code=b.dept_code
	group by b.dept_name ;
----------------------------------------------------------------------

10.
select a.Staff_Code,a.Staff_Name,b.DEPT_NAME,c.DESIGN_NAME 
	FROM STAFF_MASTER a
	join  DEPARTMENT_MASTER b on a.dept_code=b.dept_code
	join DESIGNATION_MASTER c on a.design_code=c.design_code 
	WHERE MONTHS_BETWEEN(TO_CHAR(a.HIREDATE,'MM') ,TO_CHAR(SYSDATE,'MM'))<3;  
------------------------------------------------------------------------------------
11.
select mgr_name , count(staff_code) from staff_master;
-----------------------------------------------------------------------------------

12.

---------------------------------------------------------------------------------------

4.1  Database Objects
---------------------------------------------------------------
1.
create table cust
        ( CustomerId number(5),
		  Cust_Name varchar2(20),
		  Address1 varchar2(30),
		  Address2 varchar2(30)
		 );
--------------------------------------------------------------

2.
alter table cust rename column cust_name to CustomerName;
alter table cust modify CustomerName varchar2(30) not null;
---------------------------------------------------------------

3.a)
alter table cust
add ( Gender varchar2(1),
      age number(3),
	  PhoneNo number(10)
	  );
-----------------------------------------------------
3. b)

rename cust to Cust_Table;
----------------------------------------------------------

4.
insert into Cust_table values(1000,'Allen','#115 Chicago','#115 Chicago','M','25','7878776');
insert into Cust_table values(1001,'George','#116 France','#116 France','M','25','434524');
insert into Cust_table values(1002,'Becker','#114 New York','#114 New York','M','45','431525');
---------------------------------------------------------------------------

5.
alter table cust_table
add constraint CustId_Prim PRIMARY KEY(CustomerId);
-------------------------------------------------------------------

6.
insert into Cust_table values(1002,'John','#114 Chicago','#114 Chicago','M','45','439525');
------------------------------------------------------------------------------
7.
alter table cust_table disable constraint CustId_Prim;
insert into cust_table values(1002, 'Becker', '#114 New York', '#114 New york' , 'M', '45', '431525');
insert into cust_table values(1003, 'Nanapatekar', '#115 India', '#115 India' , 'M', '45', '431525');
--------------------------------------------------------------

8.
alter table cust_table enable constraint CustId_Prim;
----------------------------------------------------------------------

9.
alter table cust_table drop constraint CustId_Prim;
insert into cust_table values(1002, 'Becker', '#114 New York', '#114 New york' , 'M', '45', '431525',15000.50);
insert into cust_table values(1003, 'Nanapatekar', '#115 India', '#114 India' , 'M', '45', '431525',20000.50);
-----------------------------------------------------------

10.
truncate table cust_table;
---------------------------------------------------------------------

11.
alter table cust_table add ( E_mail varchar2(50));
-----------------------------------------------------

12.
alter table cust_table drop column E_mail;
-----------------------------------------------------------------

13.
create table Suppliers
     (  SuppID number(5),
		  SName varchar2(20),
		  Addr1 varchar2(30),
		  Addr2 varchar2(30),
		  Contactno number(10)
	 );
--------------------------------------------------------

14.
drop table Suppliers;

create table CustomerMaster
     (  CustomerId number(5) constraint CustId_PK PRIMARY KEY ,
		  CustomerName varchar2(30) not null,
		  Address1 varchar2(30) not null,
		  Address2 varchar2(30),
		  Gender varchar2(1),
		  Age number(3),
		  PhoneNo number(10)
	 );
-----------------------------------------------------------------------

15.
create table AccountsMaster
     (    CustomerId number(5),
		  AccountNumber number(10,2) constraint Acc_PK PRIMARY KEY,
		  AccountType char(30),
		  LedgerBalance number(10,2) not null
	 );
------------------------------------------------------------------------

16.
alter table AccountsMaster
add constraint Cust_acc FOREIGN KEY(CustomerId) REFERENCES CustomerMaster(CustomerId);
--------------------------------------------------------------------

17.
insert into CustomerMaster values(1000, 'Allen', '#115 Chicago', '#115 Chicago', 'M', 25, 7878776);
insert into CustomerMaster values(1001, 'George', '#116 France', '#116 France', 'M', 25, 434524);
insert into CustomerMaster values(1002, 'Becker', '#114 New York', '#114 New York', 'M', 45, 431525);
---------------------------------------------------------------------------

18.
alter table AccountsMaster
modify AccountType char(30) check(accountType='NRI' or accountType='IND');
-------------------------------------------------------------------------------

19.
alter table AccountsMaster
modify LedgerBalance number(10,2) constraint Balance_Check check(ledgerBalance>5000);
---------------------------------------------------------------------------------------------

20.
alter table AccountsMaster drop constraint Cust_acc;

alter table AccountsMaster
add constraint Cust_acc FOREIGN KEY(CustomerId) REFERENCES CustomerMaster(CustomerId) on delete cascade;

-------------------------------------------------------------------------

21.
create table AccountDetails as select * from AccountsMaster;
-----------------------------------------------------------------------

22.
create view Acc_view( CustomerCode,AccounHolderName,AccountNumber ,Type,Balance)
  as select CustomerId,Customername,Accountnumber,AccountType,ledgerBalance
	from AccountsMaster;
----------------------------------------------------------------------

23.
create view vAccs_Dtls as select AccountType,ledgerBalance from accountsMaster where accountType='IND' and ledgerbalance>=10000;
----------------------------------------------------------------
24.
create view accsvw10 as select * from accountsmaster with read only constraint reacc;
-----------------------------------------------------------------

25. 
CREATE sequence SEQ_DEPT minvalue 40 start with 40
	increment by 10 MAXVALUE 200 cache 40;
	
	update department_master set dept_code=seq_dept.nextval;
------------------------------------------------------------------------------

26.
insert into department_master  values(seq_dept.NEXTVAL,'mech');
insert into department_master  values(seq_dept.NEXTVAL,'is');
insert into department_master  values(seq_dept.NEXTVAL,'it');
-----------------------------------------------------------
27.
drop sequence SEQ_DEPT;
----------------------------------------------------------

28.
select * from all_indexes where index_name like '%NO_NAME%';

------------------------------------------------------------------------
29.
create synonym synEmp for emp;
---------------------------------------------------------
30.
select * from synEmp;
---------------------------------------------------------------
31.
create index idx_emp_hiredate on emp(hiredate);
----------------------------------------------------------------
32.

CREATE sequence SEQ_Emp minvalue 1000 start with 1001
	increment by 1 MAXVALUE 2000 cache 1000;
	
	update emp set empno=seq_emp.nextval;
-------------------------------------------------------------------------------

5.1
--------------------------------------------------
1.
create table employee as select * from emp where 1=3;
desc employee;
select * from employee;
------------------------------------------------------------------------

2.
insert into employee (empno,ename,sal,deptno) values(7369,'SMITH',800,20);
insert into employee (empno,ename,sal,deptno) values(7499,'ALLEN',1600,30);
insert into employee (empno,ename,sal,deptno) values(7521,'WARD',1250,30);
insert into employee (empno,ename,sal,deptno) values(7566,'JONES',2975,20);
insert into employee (empno,ename,sal,deptno) values(7654,'MARTIN',1250,30);
insert into employee (empno,ename,sal,deptno) values(7698,'BLAKE',2850,30);
insert into employee (empno,ename,sal,deptno) values(7782,'CLARK',2450,10);
insert into employee (empno,ename,sal,deptno) values(7788,'SCOTT',3000,20);
insert into employee (empno,ename,sal,deptno) values(7839,'KING',5000,10);
insert into employee (empno,ename,sal,deptno) values(7844,'TURNER',1500,30);
insert into employee (empno,ename,sal,deptno) values(7876,'ADAMS',1100,20);
insert into employee (empno,ename,sal,deptno) values(7900,'JAMES',950,30);
insert into employee (empno,ename,sal,deptno) values(7902,'FORD',3000,20);
insert into employee (empno,ename,sal,deptno) values(7934,'MILLER',1300,10);
-----------------------------------------------------------------------------

3.
update employee set job=(select job from employee where empno=7788),deptno=(select deptno from employee where empno=7788)  where empno=7698;
--------------------------------------------------------------------------------------

4.
delete from employee where departmentname like '%sales%';
-------------------------------------------------------------------------

5.
update employee set deptno=(select deptno from employee where empno=7698) where empno=7788;
---------------------------------------------------------------------------------

6.
insert into employee values(&empno,'&ename','&job',&mgr,'&hiredate',&sal,&comm,&deptno);
-----------------------------------------------------------------------------------

6.1
--------------------------------------------

1.
insert into customerMaster values(&customerId,'&customername','&address1','&address2','&gender',&age,&phoneno);
--------------------------------------------------------------------------
2.
savepoint SP1;
--------------------------------------
3.
insert into customerMaster values(6003,'john','#114 chicago','#114 chicago','m',45,439525);
------------------------------------------------------------------

4.
rollback to SP1;
--------------------------------------------