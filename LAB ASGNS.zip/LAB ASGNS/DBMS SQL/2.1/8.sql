select to_char(next_day(last_day(sysdate)-7,'FRIDAY')) from dual;
