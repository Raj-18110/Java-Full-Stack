select Staff_Name, lpad(Staff_sal,15,'$') as Salary from Staff_Master;
