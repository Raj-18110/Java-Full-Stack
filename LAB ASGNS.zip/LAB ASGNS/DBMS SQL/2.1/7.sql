select instr('Mississippi', 'i',2,3) from dual;
