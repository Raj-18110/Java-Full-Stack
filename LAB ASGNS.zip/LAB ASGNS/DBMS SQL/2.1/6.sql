select staff_name,hiredate, to_char(hiredate,'DAY') as DAY from staff_master order by to_char(hiredate,'DAY') ;
