select student_name, to_char(student_dob,'MONTH DD YYYY') AS DATE_BIRTH 
	from student_master
	WHERE to_char(student_dob,'DAY') like '%SATURDAY%' or to_char(student_dob,'DAY') like '%SUNDAY%';
