drop sequence SEQ_DEPT;
