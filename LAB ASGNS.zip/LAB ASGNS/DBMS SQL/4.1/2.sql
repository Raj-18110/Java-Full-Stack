alter table cust rename column cust_name to CustomerName;
alter table cust modify CustomerName varchar2(30) not null;