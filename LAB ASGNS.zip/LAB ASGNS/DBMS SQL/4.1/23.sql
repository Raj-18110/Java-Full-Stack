create view vAccs_Dtls as select AccountType,ledgerBalance from accountsMaster where accountType='IND' and ledgerbalance>=10000;
