alter table cust_table enable constraint CustId_Prim;
