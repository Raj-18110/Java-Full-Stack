create table AccountDetails as select * from AccountsMaster;
