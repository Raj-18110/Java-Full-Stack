create table AccountsMaster
     (    CustomerId number(5),
		  AccountNumber number(10,2) constraint Acc_PK PRIMARY KEY,
		  AccountType char(30),
		  LedgerBalance number(10,2) not null
	 );