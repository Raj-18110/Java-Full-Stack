alter table AccountsMaster drop constraint Cust_acc;

alter table AccountsMaster
add constraint Cust_acc FOREIGN KEY(CustomerId) REFERENCES CustomerMaster(CustomerId) on delete cascade;