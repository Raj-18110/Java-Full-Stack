alter table AccountsMaster
modify AccountType char(30) check(accountType='NRI' or accountType='IND');