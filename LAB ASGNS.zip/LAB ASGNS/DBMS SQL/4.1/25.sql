CREATE sequence SEQ_DEPT minvalue 40 start with 40
	increment by 10 MAXVALUE 200 cache 40;
	
	update department_master set dept_code=seq_dept.nextval;