select * from all_indexes where index_name like '%NO_NAME%';
