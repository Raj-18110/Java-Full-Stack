CREATE sequence SEQ_Emp minvalue 1000 start with 1001
	increment by 1 MAXVALUE 2000 cache 1000;
	
	update emp set empno=seq_emp.nextval;