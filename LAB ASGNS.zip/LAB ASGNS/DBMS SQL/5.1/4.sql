delete from employee where departmentname like '%sales%';
