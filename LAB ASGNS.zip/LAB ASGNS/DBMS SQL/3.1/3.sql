select a.student_code,a.student_name,b.book_code,c.book_name ,b.book_expected_return_date
      from student_master a 
	  join book_transactions b on a.student_code=b.student_code 
	  join book_master c on c.book_code=b.book_code 
	  where TO_CHAR(b.BOOK_EXPECTED_RETURN_DATE,'DD MM YYYY')=TO_CHAR(SYSDATE,'DD MM YYYY'); 