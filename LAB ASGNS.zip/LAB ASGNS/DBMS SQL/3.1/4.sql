select a.staff_code,a.staff_name, b.dept_name, c.design_name, d.book_code,d.book_name, e.book_issue_date
    from staff_master a
	    join department_master b on a.dept_code=b.dept_code
	    join designation_master c on a.design_code=c.design_code
	    join book_transactions e on a.staff_code=e.staff_code
	    join book_master d on e.book_code=d.book_code
	     where months_between(to_char(e.book_issue_date,'mm'), to_char(sysdate,'mm'))<1;