select a.student_code,a.student_name,b.dept_name 
	from student_master a
	join department_master b on a.dept_code=b.dept_code
	where a.student_code in (select a.student_code from student_master group by a.dept_code having count(a.student_code)in (select max(count(a.student_code)) from student_master group by dept_code)); 