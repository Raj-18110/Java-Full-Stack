select a.staff_code as "Staff#",a.staff_name as Staff,b.dept_name,a.mgr_code as Mgr#,a.mgr_name as Manager
 from staff_master a 
 join department_master b on a.dept_code=b.dept_code;