select a.Staff_Code,a.Staff_Name,b.DEPT_NAME,c.DESIGN_NAME 
	FROM STAFF_MASTER a
	join  DEPARTMENT_MASTER b on a.dept_code=b.dept_code
	join DESIGNATION_MASTER c on a.design_code=c.design_code 
	WHERE MONTHS_BETWEEN(TO_CHAR(a.HIREDATE,'MM') ,TO_CHAR(SYSDATE,'MM'))<3;  