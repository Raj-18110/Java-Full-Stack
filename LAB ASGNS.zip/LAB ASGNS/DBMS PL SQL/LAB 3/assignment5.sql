create or replace procedure UPDATE_BOOK(
	bocode in book_transactions.book_code%TYPE,
	stcode in book_transactions.staff_code%TYPE)
is
	issueD date;
	returnD date;
	
begin
	issueD := sysdate;
	returnD := sysdate+10;
	IF (to_char(returnD, 'fmD') = 1) THEN
		returnD := returnD+1;
	ELSIF (to_char(returnD, 'fmD') = 7) THEN
		returnD := returnD+2;
	END IF;

	INSERT INTO book_transactions (book_code, staff_code, book_issue_date, book_expected_return_date)
		VALUES (bocode, stcode, issueD, returnD);
end ;
/

exec UPDATE_BOOK(1001,101);
/